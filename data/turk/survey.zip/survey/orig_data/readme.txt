Quick update here re ideology ratings (vars libcon_1-6) - don't think we have any other variables on same scale to compare these to (do we?).  But comparing these vars to each other maybe some interesting/useful results.  Some evidence perceived extremeness trends down for politicians named later for out party but not for in party.  (i.e. dem1 on avg more liberal than dem2, who's more liberal than dem3 for repub/indep respondents, whereas this isn't true for dems perceptions of dems).  Ie most extreme pols come to mind first?  Pattern is weaker for perceptions of repubs  Is true for Boehner, not true for W, could explore this kind of thing some more..)

(also fyi  number of diff names still much higher for repubs when sample split by party/ideology of respondent)
Feel free to shoot over any thoughts/suggestions

 bysort pid3: sum libcon_1 libcon_3 libcon_5

---------------------------------------------------------------------------------------------------------------------------------------------------------
-> pid3 = Democrat

    Variable |       Obs        Mean    Std. Dev.       Min        Max
-------------+--------------------------------------------------------
    libcon_1 |       192    2.692187    1.166815          1          7
    libcon_3 |       192    2.584896    1.150975          1          7
    libcon_5 |       192    2.729167    1.147172          1          7

---------------------------------------------------------------------------------------------------------------------------------------------------------
-> pid3 = Independent

    Variable |       Obs        Mean    Std. Dev.       Min        Max
-------------+--------------------------------------------------------
    libcon_1 |        45    2.344444    1.288508          1          6
    libcon_3 |        45    2.555556    1.389499          1          7
    libcon_5 |        45    2.757778    1.359059          1        6.1

---------------------------------------------------------------------------------------------------------------------------------------------------------

---------------------------------------------------------------------------------------------------------------------------------------------------------
-> pid3 = Republican

    Variable |       Obs        Mean    Std. Dev.       Min        Max
-------------+--------------------------------------------------------
    libcon_1 |       106    1.817925    1.144827          1          7
    libcon_3 |       106    1.985849    1.260645          1        6.7
    libcon_5 |       106    2.292453    1.310812          1          7


. bysort pid3: sum libcon_2 libcon_4 libcon_6

---------------------------------------------------------------------------------------------------------------------------------------------------------
-> pid3 = Democrat

    Variable |       Obs        Mean    Std. Dev.       Min        Max
-------------+--------------------------------------------------------
    libcon_2 |       192    6.007292    1.047585          2          7
    libcon_4 |       191    6.029319    1.169786          1          7
    libcon_6 |       192    5.858333    1.281701          1          7

---------------------------------------------------------------------------------------------------------------------------------------------------------
-> pid3 = Independent

    Variable |       Obs        Mean    Std. Dev.       Min        Max
-------------+--------------------------------------------------------
    libcon_2 |        45    5.526667    1.115062          3          7
    libcon_4 |        45    5.693333    1.069069        3.1          7
    libcon_6 |        45    5.364444    1.420332          1          7


---------------------------------------------------------------------------------------------------------------------------------------------------------
-> pid3 = Republican

    Variable |       Obs        Mean    Std. Dev.       Min        Max
-------------+--------------------------------------------------------
    libcon_2 |       106     5.75283    1.109715          2          7
    libcon_4 |       106    5.742453    1.072243        2.2          7
    libcon_6 |       106    5.691509    1.256459          1          7